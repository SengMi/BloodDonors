<?php
session_start();
$user_id = $_SESSION['user_id'] ?? 'Unknown User';

// Log the logout event
error_log("User {$user_id} logged out on " . date("Y-m-d H:i:s"));

// Destroy the session
session_destroy();

// Redirect to the index page with a logout confirmation message
header('location:index.php?logout=success');
?>
